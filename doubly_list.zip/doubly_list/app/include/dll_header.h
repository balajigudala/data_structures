#include <stdio.h>

void* dll_init_list(void*, unsigned int);
int dll_insert_node(void*, unsigned int, unsigned int);
int dll_print_list(void*, FILE*);
int dll_delete_list(void*);
int dll_retrive_data(void*, unsigned int, unsigned int*);
int dll_update_data(void*, unsigned int, unsigned int);
int dll_remove_node(void*, unsigned int);
int dll_remove_nodes_with_specific_data(void*, unsigned int);
int consecutive_duplicates(void*);

