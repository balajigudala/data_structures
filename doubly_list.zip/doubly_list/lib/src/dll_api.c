#include <errno.h>
#include <stdlib.h>

#include "../include/dll_header.h"

struct node {
	struct node* prev; /**<It is used to store the previous node address*/
	unsigned int data; /**<It is used to store the data in node*/
	struct node* next; /**<It is used to store the next node address*/ 
};

struct dll_info {
	struct node* head; /**<The starting node address of the list*/ 
	unsigned int max;  /**<To store the maximum no of nodes in list*/
	unsigned int cnt;  /**<The store no of nodes present in that list*/ 
	struct node* tail; /**<The last node address of the list*/
};

/**
 * Initializing the list size.
 *
 * This function helps the user to set the limit for list size(@max).Here dynamically allocate
 some memory to store the head address, maximum nodes, nodes count in list, last node 
 address in list.

 * @param head will hold the adress of starting list node address.
 * @param range holds the data of maximun no of nodes which wants to limit the list size.
 *
 * @return NULL : if already the list is initialized.
   head address : if the list is initialized.
*/
void* dll_init_list(void* head, unsigned int range)   
{
	struct dll_info* temp = (struct dll_info*)head;

	if (temp != NULL)
		return NULL;

	temp = (struct dll_info*)malloc(1 * sizeof(struct dll_info));
	if (temp == NULL)
		return NULL;

	temp->max = range;
	temp->head = NULL;
	temp->tail = NULL;
	temp->cnt = 0;

	return temp;
}


/**
 * Inserting node in the specific position.
 *
 * This function helps to insert the data in specific location. The dll_info is sent to 
 function and add the node which is created dynamically and adding data in the specific 
 location.
 *
 * @param head will hold the address of starting node address.
 * @param idx the position in which node the data to be added.
 * @param data will hold the data that to be added.
 *
 * @return -EIO     : if the list is not intialised.
           -ERANGE  : if the list range is initialized with zero.
 	   -ELNRNG  : if the list is filled.
 	   -ENODATA : if the list is empty.
 	   -ENOMEM  : if the allocation of new node is failed.
 	   -EINVAL  : if the positon is greater than the nodes present in list.
       		 0  : if the node is inserted in specific location.
*/
int dll_insert_node(void* head, unsigned int idx, unsigned int data) 
{
	struct dll_info* temp = (struct dll_info*)head;
	struct node *alloc_mem, *node;
	unsigned int count = 1;

	/*In if block, verifying the list is initialised or not.*/ 
	if (temp == NULL)                  
		return -EIO;
	
	if (temp->max == 0)
		return -ERANGE;

	node = temp->head;

	/*checking the no of nodes in list is in range or not */
	if (temp->cnt >= temp->max)             
		return -ELNRNG;

	/*checking if the given postion is greater than the nodes present in list*/
	if ((temp->cnt + 1 < idx) || (idx == 0))
		return -EINVAL;

	/*checking it is the first first node and position is greater than one */
	if ((node == NULL) && (idx > 1))         
		return -ENODATA;

	alloc_mem = (struct node*)malloc(1 * sizeof(struct node));
	/* verifying DMA call was successfull or not */
	if (alloc_mem == NULL)                        
		return -ENOMEM;

	alloc_mem->data = data;

	/* if list was empty and it was the first node to add */
	if (idx == 1) {
		if(node == NULL) {	
			alloc_mem->next = NULL;
			temp->tail = alloc_mem;
		} else {
			alloc_mem->next = temp->head;
			node->prev = alloc_mem;
		}

		alloc_mem->prev = NULL;
		temp->head = alloc_mem;
		temp->cnt++;
	} else if (temp->cnt+1 == idx) {                   
		alloc_mem->prev = temp->tail;
		alloc_mem->next = NULL;
		temp->tail->next = alloc_mem;
		temp->tail = alloc_mem;
		temp->cnt++;
	} else {
		/* traversing list up to last node */
		while (node != NULL) {                   
			if (count == idx) {
				alloc_mem->prev = node->prev;
				alloc_mem->next = node;
				node->prev->next = alloc_mem;
				node->prev = alloc_mem;
				temp->cnt++;

				break;
			}

			count++;
			node = node->next;
		}
	}

	return 0;
}


/**
 * Deleting the list
 *
 * This function helps to free all nodes present in the list.
 *
 * @param head hold the address of the starting list addrees.
 *
 * @return -ENODATA : if the list is empty.
           -EIO     : if the list is not initialised.
                  0 : The deletion(free) of the nodes is succesfull.
*/
int dll_delete_list(void* head)                      
{
	struct node *del_node, *node;
	struct dll_info *temp = (struct dll_info *)head;

	/*In if block, verifying the list is initialised or not.*/ 
	if (temp == NULL)                  
		return -EIO;
		
	if (temp->cnt == 0)           
		return -ENODATA;

	node = temp->head;

	while (node != NULL) {
		del_node = node;
		node = node->next;                
		free(del_node);
	}

	temp->head = NULL;
	temp->tail = NULL;
	temp->cnt = 0;

	return 0;
}

/**
 * Printing the data present in list
 *
 * This function helps to print the data in nodes. Based on file decritor the data is copied 
 there.
 *
 * @param head hold the address of the starting list address.
 * @param fp hold the file descriptor.
 *
 * @return -EIO     : if the list is not intialized.
           -ENODATA : if the list is empty.
                  0 : if the printing is success.
*/

int dll_print_list(void* head, FILE *fp)
{
	struct dll_info *temp = (struct dll_info*)head;
	struct node *node;

	/*In if block, verifying the list is initialised or not.*/ 
	if (temp == NULL)                  
		return -EIO;
		
	if (temp->cnt == 0)           
		return -ENODATA;

	node = (struct node*)temp->head;

	while(node != NULL) {
		fprintf(fp, "%-4d ",node->data);
		node = node->next;
	}

	return 0;
}




/**
 * Retrieve a node data from specific location.
 *
 * finding the position of the node and returning the data from that specific node.
 *
 * @param head will hold the address of starting node address.
 * @param idx the position in which the data is retrived from the specific node.
 * @param data will hold the retrived data.
 *
 * @return -ENODATA : if the list is empty.
           -EIO     : if the list is not initialized.
           -EINVAL  : if position is not found.
                  0 : found the position and retrived data.
*/
int  dll_retrive_data(void* head, unsigned int idx, unsigned int* data)
{
	unsigned int count = 1;
	struct dll_info* temp = (struct dll_info*)head;
	struct node* node;

	/*In if block, verifying the list is initialised or not.*/ 
	if (temp == NULL)                  
		return -EIO;
		
	if (temp->cnt == 0)           
		return -ENODATA;

	/* verifying the no of nodes with the given position */
	if ((temp->cnt < idx) || (idx == 0))  
		return -EINVAL;

	node = temp->head;

	while (node != NULL) {
		if (count == idx) {
			*data = node->data;

			return 0;
		}

		node = node->next;
		count++;
	}
}

/**
 * Update node data at specific location.
 *
 * This function is used for finding the position and to update the data in that node.
 *
 * @param head will hold the address of starting node address.
 * @param idx the position in which the data to be updated.
 * @param data will hold the data to be updated.
 *
 * @return -ENODATA : if the list is empty.
           -EIO     : if the list is not initialized.
           -EINVAL  : if the position is not found.
                  0 : found the position and updated data.
*/
int dll_update_data(void* head, unsigned int idx, unsigned int data)
{
	struct dll_info* temp = (struct dll_info*)head;
	struct node* node;
	unsigned int count=1;

	/*In if block, verifying the list is initialised or not.*/ 
	if (temp == NULL)                  
		return -EIO;
		
	if (temp->cnt == 0)           
		return -ENODATA;

	node = temp->head;

	/* verifying the no of nodes with position given */
	if ((temp->cnt < idx) || (idx == 0))   
		return -EINVAL;

	while (node != NULL) {
		if (count == idx) {
			node->data = data;
			return 0;
		}

		node = node->next;
		count++;
	}
}

/**
 * Remove Nth node from Linked-list.
 *
 * This function helps to delete the node based on the position.
 *
 * @param head will hold the address of starting node address.
 * @param idx the node to be deleted at purticular position. 
 *
 * @return -ENODATA : if the list is empty.
           -EIO     : if the list is not initialised.
           -EINVAL  : if the position is not found.
                  0 : found the position and deleted the node.
*/
int  dll_remove_node(void* head, unsigned int idx)
{
	struct dll_info* temp = (struct dll_info*)head;
	struct node* node, *del_node;
	int count = 1;

	/*In if block, verifying the list is initialised or not.*/ 
	if (temp == NULL)                  
		return -EIO;

	if (temp->cnt == 0)           
		return -ENODATA;

	node = temp->head;

	/* verifying no of nodes with position given */
	if ((temp->cnt < idx) || (idx == 0))  
		return -EINVAL;

	if(temp->cnt == idx) {
		del_node = temp->tail;

		if (temp->tail->prev == NULL)
			temp->head = NULL;
		else
			temp->tail->prev->next = NULL;

		temp->tail = temp->tail->prev;
		free(del_node);
		temp->cnt--;
	} else { 
		while (node != NULL) {
			if (idx == count) {
				if (node->prev == NULL)
					temp->head = node->next;
				else
					node->prev->next = node->next;

				if (node->next != NULL)
					node->next->prev = node->prev;

				temp->cnt--;

				break;
			}

			count++;
			node = node->next;
		}
	}

	return 0;
}

/**
 * Remove all nodes containing a value 'n'.
 *
 * This function helps to delete the all the nodes with the data given by the user.
 *
 * @param head holds the address of starting node address.
 * @param data The data is used to delete the nodes with same data.
 *
 * @return -ENODATA : if the list is empty.
           -EIO     : if the list is not initialized.
           -EINVAL  : if the data is not found in list.
                  0 : found the nodes and deleted them.
*/
int dll_remove_nodes_with_specific_data(void *head, unsigned int data)
{
	struct dll_info* temp = (struct dll_info *)head;
	struct node* node, *del_node;
	int count = 1, flag = 0;

	/*In if block, verifying the list is initialised or not.*/ 
	if (temp == NULL)                  
		return -EIO;

	if (temp->cnt == 0)           
		return -ENODATA;

	node = temp->head;

	while (node != NULL) {
		if (node->data == data) {

			if(node == temp->tail)
				temp->tail = node->prev;

			if (node->prev == NULL)
				temp->head = node->next;
			else
				node->prev->next = node->next;

			if (node->next != NULL)
				node->next->prev = node->prev;

			flag = 1;
			del_node = node;
			node = node->next;
			temp->cnt--;
			free(del_node);

			continue;
		}

		count++;
		node = node->next;
	}

	if (flag)
		return 0;
	
	return -EINVAL;

}


int consecutive_duplicates(void *head)
{
	struct dll_info *temp = (struct dll_info*)head;
	struct node *node, *del_node, *new_node;
	unsigned int data = 0, flag = 0, stat = 0;

	if (temp == NULL)
		return -EIO;

	if (temp->cnt == 0)
		return -ENODATA;

	for(node = temp->head; node !=  NULL;) {
		for(flag = 0, new_node = node->next; new_node != NULL; free(del_node)) {
			if (node->data != new_node->data)
			break;

			stat = 1;
			flag = 1;
			
			if (new_node->next == NULL)
				temp->tail = node;
			else
				new_node->next->prev = node;
		
			node->next = new_node->next;
			del_node = new_node;
			new_node = new_node->next;
			temp->cnt--;	
		}
		
		if (flag == 1) {
			if (node->prev == NULL)
				temp->head = node->next;
			else
				node->prev->next = node->next;
			
			if (node->next == NULL)
				temp->tail = node->prev;
			else
				node->next->prev = node->prev;
			del_node = node;
			node = node->next;
			temp->cnt--;
			free(del_node);
			continue;
		}

		node = node->next;
	}

	if (stat == 1)
		return 0;
	return -EINVAL;
}
